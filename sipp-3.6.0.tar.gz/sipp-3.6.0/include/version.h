#define SIPP_VERSION "v3.6.0"
